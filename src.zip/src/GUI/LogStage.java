package GUI;

/**
 * @author SINLORDEP
 */

public enum LogStage {
    ONGOING, PASS, FAIL, ERROR, INFO
}
