package exceptions;

/**
 * @author SIN
 */
public class ObjectDBException extends RuntimeException {
    public ObjectDBException(String message) {
        super(message);
    }
}
