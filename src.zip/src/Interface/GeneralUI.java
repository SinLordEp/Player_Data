package Interface;

/**
 * @author SIN
 */
public interface GeneralUI {
    void run();
}
