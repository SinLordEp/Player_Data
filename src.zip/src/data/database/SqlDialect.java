package data.database;

/**
 * @author DAM2
 */

public enum SqlDialect {
    NONE, MYSQL, SQLITE
}
