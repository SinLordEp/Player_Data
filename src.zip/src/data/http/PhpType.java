package data.http;

/**
 * @author SIN
 */

public enum PhpType {
    NONE, JSON
}
