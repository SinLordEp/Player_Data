package data;

/**
 * @author SIN
 */

public enum DataOperation {
    ADD, MODIFY, DELETE
}
